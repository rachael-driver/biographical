Portfolio website

This is my portfolio website. It provides information about my background and my work as a web developer.

Built With:

HTML, CSS

Key Features:

The website consists of four pages:

1. The home page, which provides a brief introduction to my background and my goals as a developer.
2. The about page, which provides a more detailed description of my background and my development sklils & experience.
3. The work page, which provides information and links to work that I have completed.
4. The contact page, which provides information about how to contact me.